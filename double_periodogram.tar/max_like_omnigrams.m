% max_like_ommigrams.m
% Construct Least-Squares/Mximum-Likelihood double omnigram;

mm = 4; % Set the number of terms in the modeln (e.g., 4 for two sinusoids)
% This case can be generalized to other values of mm



disp('==================================================')
disp('  Maximum Likelihood/Least Squares Periodograms.')
disp('==================================================')

for do_lomb = 0:1 % Use the Lomb phase term if do_lomb not 0

    disp('----------------------------------------------------------------')
    if do_lomb == 0
        disp('Schuster-style Double Periodogram (no Lomb phase shift).')
    else
        disp('LS-style Double Periodogram (using Lomb phase term).')
    end
    disp('----------------------------------------------------------------')
    
    % First Define symbolic variables
    for jj = 1:mm
    
        % Model amplitude variables  B_{j} 
        st = ['B' int2str( jj ) ];
        eval( ['B' int2str( jj ) ' = sym(st);'] );
    
        % Inner products of basis functions with the data:
        % dG_{j} ==  (1/N) Sum_{i} [ d_{i} G_{j}( t_{i} ) 
        st = ['dG' int2str( jj ) ];
        eval( ['dG' int2str( jj ) ' = sym(st);'] );
    
        % Cross products of basis functions:
        % gg_{j,k} = (1/N) Sum_{i} G_{j}( t_{i} ) G_{k}( t_{i} ) 
        for kk = jj: mm 
            st = sym( ['gg' int2str( jj ) int2str( kk ) ]);
            eval( [' gg' int2str( jj ) int2str( kk )  '= st ;'] );
        end
    end
    
    % Data inner products for the log-likelihood
    for jj = 1:mm
    
        this_term = [ '-2*B' int2str(jj ) '* dG' int2str(jj )];
        if jj == 1
           Q = str2sym( this_term );
        else
           Q = Q + str2sym( this_term );
        end
    
    end
    
    % Basis inner products: diagonal terms 
    for jj = 1:mm
        this_term = str2sym( ['B' int2str(jj ) '^2 * gg'  int2str(jj) int2str(jj)  ] );
        Q = Q +  this_term;
    end
    
    if do_lomb == 0 
        % Basis inner products: above diagonal terms 
        for jj = 1:mm
        for kk = jj+1: mm 
            this_term = str2sym( ['2 * B' int2str(jj ) '* ' ...
                                      'B' int2str(kk ) '* ' ...
                                     'gg' int2str(jj) int2str(kk)  ] );
            Q = Q +  this_term;
        end
        end
    else
        % Basis inner products: above diagonal terms 
        % for Lomb, skip if jj odd and kk == jj + 1
        for jj = 1:mm
        for kk = jj+1: mm 
            this_term = str2sym( ['2 * B' int2str(jj ) '* ' ...
                                          'B' int2str(kk ) '* ' ...
                                         'gg' int2str(jj) int2str(kk)  ] );
            % remove if jj odd and kk == jj + 1
            if rem( jj, 2 ) ==  1 & kk == jj + 1
                %disp([ 'no soap ' char( this_term  )] )
            else
                Q = Q +  this_term;
            end
        end
        end
    end
    
    disp('Mean Square data-model residuals:')

    disp( Q )
    %%
    % Generate solution for m = 4
    
    dq1 = diff( Q, B1 )/2;
    dq2 = diff( Q, B2 )/2;
    dq3 = diff( Q, B3 )/2;
    dq4 = diff( Q, B4 )/2;
    
    eqs_this = [ dq1==0, dq2==0, dq3==0, dq4 ==0 ];
    
    sol_this = solve( eqs_this, [ B1 B2 B3 B4 ]);%,'ReturnConditions',true);
    B1 = sol_this.B1;
    B2 = sol_this.B2;
    B3 = sol_this.B3;
    B4 = sol_this.B4;
    
    [ num_1, den_1 ] = numden( B1 );% all denominators are the same
    [ num_2, den_2 ] = numden( B2 );
    [ num_3, den_3 ] = numden( B3 );
    [ num_4, den_4 ] = numden( B4 );
    
    disp('Common denominator for the amplitude parameters:')
    disp( den_1 )
     
     %=========================================================================
     %        Process numerators
     %=========================================================================
     disp('Numerators for the amplitude parameters:')

    for ii_numerator = 1: mm
    
        disp([ '============== ' int2str( ii_numerator )  ' ==================' ])
       
        eval( ['num_this = num_' int2str( ii_numerator) ';'])
      
        [ cc, ff ] = coeffs( num_this, [ dG1 dG2 dG3 dG4 ]);
        num_terms = length( cc );
    
        for ii = 1: num_terms
        
            %disp([ '============== ' int2str( ii )  ' ==================' ])
            cc_this = cc( ii );
            facs_this = factor( cc_this );
            num_facs = length( facs_this );
        
            name_this = char( ff(ii) );
            name_this( findstr( name_this, '^' ) ) = 'p';
            name_this( findstr( name_this, '*' ) ) = 'x';
        
            % Display for cut-and-paste
    
            if num_facs == 1
                disp( [ 'Q_' name_this  ' = ' char( facs_this ) ';'] )
            elseif num_facs == 2
                disp( [ 'Q_' name_this  ' = ' char( facs_this(1) ) ' * ( ' char( facs_this(2) ) ' ); '] )
            else
                error(['too many' ])
            end
          
        end
        
        st_numerator = [' Numerator_' int2str( ii_numerator ) ' = '];
        for ii = 1: num_terms
        
            name_this = char( ff(ii) );
            name_this( findstr( name_this, '^' ) ) = 'p';
            name_this( findstr( name_this, '*' ) ) = 'x';
            if ii < num_terms
               st_numerator = [ st_numerator 'Q_' name_this '*' char( ff(ii) ) ' + ' ];
            else
                st_numerator = [ st_numerator 'Q_' name_this '*' char( ff(ii) ) ';' ];
            end
        end
        eval( ['num_str_' int2str( ii_numerator ) ' = st_numerator;'])
    
        disp( st_numerator )
    end

end

disp('====================================================================')
disp([])
return
%%

P = eval( Q );

return 
% decompose

[ num, den ] = numden( P );
[ cc, ff ] = coeffs( num, [ dG1 dG2 dG3 dG4 ]);
num_terms = length( cc )


for ii = 1: num_terms

    %disp([ '============== ' int2str( ii )  ' ==================' ])
    cc_this = cc( ii );
    facs_this = factor( cc_this );
    num_facs = length( facs_this );

    name_this = char( ff(ii) );
    name_this( findstr( name_this, '^' ) ) = 'p';
    name_this( findstr( name_this, '*' ) ) = 'x';

    if num_facs == 1
        disp( [ 'Q_' name_this  ' = ' char( facs_this ) ';'] )
    elseif num_facs == 2
        disp( [ 'Q_' name_this  ' = ' char( facs_this(1) ) ' * ( ' char( facs_this(2) ) ' ); '] )
    else
        error(['too many' ])
    end
  
end

st_numerator = [' NUM = '];
for ii = 1: num_terms

    
    name_this = char( ff(ii) );
    name_this( findstr( name_this, '^' ) ) = 'p';
    name_this( findstr( name_this, '*' ) ) = 'x';
    if ii < num_terms
       st_numerator = [ st_numerator 'Q_' name_this '*' char( ff(ii) ) ' + ' ];
    else
        st_numerator = [ st_numerator 'Q_' name_this '*' char( ff(ii) ) ';' ];
    end
end
st_numerator 

return

for ii = 1: num_terms

    %disp([ '============== ' int2str( ii )  ' ==================' ])
    cc_this = cc( ii );
    facs_this = factor( cc_this );
    num_facs = length( facs_this );

    name_this = char( ff(ii) );
    name_this( findstr( name_this, '^' ) ) = 'p';
    name_this( findstr( name_this, '*' ) ) = 'x';

    if num_facs == 1
        disp( [ 'Q_' name_this  ' = ' char( facs_this ) ';'] )
    elseif num_facs == 2
        disp( [ 'Q_' name_this  ' = ' char( facs_this(1) ) ' * ( ' char( facs_this(2) ) ' ); '] )
    else
        error(['too many' ])
    end
  
end

st_numerator = [' NUM = '];
for ii = 1: num_terms

    
    name_this = char( ff(ii) );
    name_this( findstr( name_this, '^' ) ) = 'p';
    name_this( findstr( name_this, '*' ) ) = 'x';
    if ii < num_terms
       st_numerator = [ st_numerator 'Q_' name_this '*' char( ff(ii) ) ' + ' ];
    else
        st_numerator = [ st_numerator 'Q_' name_this '*' char( ff(ii) ) ';' ];
    end
end
st_numerator 


