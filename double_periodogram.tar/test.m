% test.m
% test script for the double periodograms
clear all
randn('seed', 54321)
rand('seed', 12345)
two_pi = 2 * pi;

% Generate time series: two sinusoids plus noise, sampled randomly in time
nxt = 1000;                              % length of time series
tt_max = 10000;                          % time range
tt_vec = sort( tt_max * rand( nxt, 1 ) );% random sample times

% Fundamental frequency, in radians per unit time
ww_fund     = two_pi / ( max(tt_vec) - min( tt_vec) );
ww_over     = 50;% frequency oversampling factor; 50 is rather large
ww_fund_use = ww_fund / ww_over;% Effective fundamental 

% Set frequencies and amplitudes of the two sinusoids
rayleigh_parameter = .5;% Frequency separation: fraction of fundamental
ww_11 = .0235;% Frequency of one component
ww_22 = ww_11 + rayleigh_parameter * ww_fund;
amp_11 = 1; % Amplitude of sinusoid #1
amp_22 = 1; % Amplitude of sinusoid #2

xx_sine_1 = sin( ww_11 * tt_vec );
xx_sine_2 = sin( ww_22 * tt_vec );

% Set frequencies scanned in the periodograms
delt = .001;
ww_min = ww_11 - delt;
ww_max = ww_22 + delt;
ww_vec = ww_min: ww_fund_use: ww_max;

% Noise parameters
noise_fac = .05;
xx_noise = randn( size( xx_sine_1 ) );% Gaussian noise
xx_vec = amp_11 * xx_sine_1 + amp_22 * xx_sine_2 + noise_fac * xx_noise;

clear data_in 
%data_in.wt_vec = wt_vec;% comment this out to do unweighted periodograms
data_in.tt_vec = tt_vec(:);
data_in.xx_vec = xx_vec(:);
data_in.ft_sign  = -1;
data_in.tt_zero  = min( data_in.tt_vec );
data_in.ww_11_vec = ww_vec(:);
data_in.ww_22_vec = ww_vec(:);
data_in.tt_vec = tt_vec(:);

 

data_dsp_out  = double_schuster( data_in );
schuster_mat = data_dsp_out.dsp_mat;

data_dlsp_out = double_lomb_scargle( data_in );
dlsp_mat = data_dlsp_out.dlsp_mat;
        
data_bretthorst_schuster_out = double_bretthorst_schuster( data_in );
bretthorst_schuster_mat = data_bretthorst_schuster_out.bayes_mat;

double_bretthorst_lomb_scargle_out  = double_bretthorst_lomb_scargle( data_in );
bretthorst_lomb_scargle_mat = double_bretthorst_lomb_scargle_out.bayes_mat;


%% do 1D LS

clear data_1d_in
data_1d_in.tt_vec = tt_vec(:);
data_1d_in.xx_vec = xx_vec(:);

data_1d_in.ft_sign  = -1;
data_1d_in.tt_zero  = min( data_in.tt_vec );
data_1d_in.ww_vec = ww_vec(:);

data_1d_out = ft_uneven( data_1d_in );
ls_vec = data_1d_out.ls_vec;
for ii = 1: length( ls_vec )
    ls_diag(ii) = dlsp_mat(ii,ii);
end
ls_diag = - ls_diag;
ls_diag = ls_diag / max( ls_diag );

figure(1)
clf
plot( ww_vec, ls_vec/max(ls_vec ) )
hold on
plot( ww_vec, ls_diag .^ 2  )

figure(2)
clf
num_con = 32;% number of contours
for ii = 1: 4

    if     ii == 1 
        this_mat = -schuster_mat;
        st_title = 'Double Schuster';
    elseif ii == 2
        this_mat = -dlsp_mat;
        st_title = 'Double Lomb-Scargle';
    elseif ii == 3
        this_mat = bretthorst_schuster_mat;
        st_title = 'Double Bretthorst-Schuster';
    elseif ii == 4
        this_mat = bretthorst_lomb_scargle_mat;
        st_title = 'Double Bretthorst-Lomb-Scargle';

    end

    subplot( 1, 4, ii )

    contour( ww_vec, ww_vec, this_mat, num_con, '-k'  )
    hold on
    set(plot( ww_22, ww_11, 'sm'),'MarkerSize', 12,'LineWidth', 2 )
    [ aa, bb ] = find( this_mat == max( this_mat(:) ));
    ab = [ aa bb ]; % possibly both maxima 
    set(plot( ww_vec(max(ab(:))), ww_vec(min(ab(:))), '.r'),'MarkerSize', 14 )
    v=axis;
    plot( [ v(1) v(2) ],  [ v(1) v(2) ], '-k')
    title( st_title)

end
%--------------------------------------------------------------------------


return