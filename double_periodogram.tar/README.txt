README

This repository contains both code, and symbolic algebra scripts 
for generating this code, including various generalizations of 
the underlying time series model and the resulting periodograms.


This code supports the paper:
Studies in Astronomical Time Series Analysis:  VIII.
The Double Lomb-Scargle Periodogram and Super Resolution
Jeffrey D. Scargle and  Sarah M. Wagner
https://arxiv.org/abs/2601.04552

The major change from this paper is a new way to deal
with the singularies on the equal-frequency diagonal.
The algorithm here for the double Schuster case 
places the 1D periodogram on this diagonal (but also 
returns the interpolated one separately in interp.vec).
This effects a likelihood ratio for the nested models 
consting of both single and double sinusoids. 
It is not yet clear if something like this will work
for the other double periodograms.


MATLAB:

Two MatLab scripts derive omnigrams using symbolic algebra:
max_like_ommigrams.m 
bayesian_omnigrams.m

test.m — synthetic data consisting of two sine waves close in frequency. 
The first plot shows the 1D Lomb-Scargle Periodograms of the two
sinusoies.
The four double periodograms are then shown as contour plots. 
True frequency values of the test signal are magenta squares; 
maxima of the double periodograms are red dots.

The parameter rayleigh_parameter (set at .5) be changed to 
explore other separations.


double_schuster.m 
double_lomb_scargle.m 
double_bretthorst_schuster.m 
double_bretthorst_lomb_scargle.m 


PYTHON:
TBD