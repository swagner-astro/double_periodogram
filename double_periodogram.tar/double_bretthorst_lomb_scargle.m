function data_out = double_bayes_nosc( data_in )

xx_vec    = data_in.xx_vec(:);   % samples
tt_vec    = data_in.tt_vec(:);   % sample times  
ww_11_vec = data_in.ww_11_vec(:);% first frequecies (radians per unit time)
ww_22_vec = data_in.ww_22_vec(:);% second frequecies

if isfield( data_in, 'wt_vec') 
    wt_vec = data_in.wt_vec;
    if find( wt_vec < 0 )
        error('Error: negative weight')
    end
    wt_vec = wt_vec / sum( wt_vec );% Ensure normalization
    do_weights = 1;
else
    do_weights = 0;
end

num_11_ww = length( ww_11_vec );% number of frequencies
num_22_ww = length( ww_22_vec );

bayes_mat = NaN * ones( num_11_ww, num_22_ww );% Initialize arrays

for ii_11_ww = 1: num_11_ww

    ww_11 = ww_11_vec( ii_11_ww );

    % Implement the Lomb phase shift term
    if do_weights > 0 
        csum_11 = sum( wt_vec .* cos( 2.0 * ww_11 * tt_vec ) );
        ssum_11 = sum( wt_vec .* sin( 2.0 * ww_11 * tt_vec ) );
    else
        csum_11 = sum( cos( 2.0 * ww_11 * tt_vec ) );
        ssum_11 = sum( sin( 2.0 * ww_11 * tt_vec ) );
    end
    wtau_11 = 0.5 * atan2( ssum_11, csum_11 );
    tt_11 = ww_11 * tt_vec - wtau_11;
    sin_11_vec =  sin( tt_11 );
    cos_11_vec =  cos( tt_11 );

    if do_weights > 0 

        gg11 = sum( wt_vec .* abs( cos_11_vec ).^ 2);
        gg22 = sum( wt_vec .* abs( sin_11_vec ).^ 2);
        dG1  = sum( wt_vec .* xx_vec .* cos_11_vec );
        dG2  = sum( wt_vec .* xx_vec .* sin_11_vec );

    else

        gg11 = sum( abs( cos_11_vec ).^ 2);
        gg22 = sum( abs( sin_11_vec ).^ 2);
        dG1  = sum( xx_vec .* cos_11_vec );
        dG2  = sum( xx_vec .* sin_11_vec );

    end

    for ii_22_ww = 1: num_22_ww

        ww_22 = ww_22_vec( ii_22_ww );

        if ww_22 ~=  ww_11  % Ignore the diagonal for now 
             
            % Implement the Lomb phase shift term
            if do_weights > 0 
                csum_22 = sum( wt_vec .* cos( 2.0 * ww_22 * tt_vec ) ); % phase term
                ssum_22 = sum( wt_vec .* sin( 2.0 * ww_22 * tt_vec ) );
            else
                csum_22 = sum( cos( 2.0 * ww_22 * tt_vec ) ); % phase term
                ssum_22 = sum( sin( 2.0 * ww_22 * tt_vec ) );
            end
            wtau_22 = 0.5 * atan2( ssum_22, csum_22 );
            tt_22 = ww_22 * tt_vec - wtau_22;
            sin_22_vec =  sin( tt_22 );
            cos_22_vec =  cos( tt_22 );
            
            if do_weights > 0 

                gg33 = sum( wt_vec .* abs( cos_22_vec ).^ 2);
                gg44 = sum( wt_vec .* abs( sin_22_vec ).^ 2);
                dG3  = sum( wt_vec .* xx_vec .* cos_22_vec );
                dG4  = sum( wt_vec .* xx_vec .* sin_22_vec );

                gg13 =  sum( wt_vec .* cos_11_vec .* cos_22_vec );
                gg24 =  sum( wt_vec .* sin_11_vec .* sin_22_vec );
                gg14 =  sum( wt_vec .* cos_11_vec .* sin_22_vec );
                gg23 =  sum( wt_vec .* sin_11_vec .* cos_22_vec );

            else

                gg33 = sum( abs( cos_22_vec ).^ 2);
                gg44 = sum( abs( sin_22_vec ).^ 2);
                dG3  = sum( xx_vec .* cos_22_vec );
                dG4  = sum( xx_vec .* sin_22_vec );

                gg13 =  sum( cos_11_vec .* cos_22_vec );
                gg24 =  sum( sin_11_vec .* sin_22_vec );
                gg14 =  sum( cos_11_vec .* sin_22_vec );
                gg23 =  sum( sin_11_vec .* cos_22_vec );

            end
              
           %===================================================================

           num_bayes =  ...
                  (gg44*dG1^2*gg23^2 + gg33*dG1^2*gg24^2 - gg22*gg33*gg44*dG1^2 ...
               - 2*gg44*dG1*dG2*gg13*gg23 - 2*gg33*dG1*dG2*gg14*gg24 ...
               - 2*dG1*dG3*gg13*gg24^2 + 2*gg22*gg44*dG1*dG3*gg13 ...
               + 2*dG1*dG3*gg14*gg23*gg24 + 2*dG1*dG4*gg13*gg23*gg24 ...
               - 2*dG1*dG4*gg14*gg23^2 + 2*gg22*gg33*dG1*dG4*gg14 ...
               + gg44*dG2^2*gg13^2 + gg33*dG2^2*gg14^2 - gg11*gg33*gg44*dG2^2 ...
               + 2*dG2*dG3*gg13*gg14*gg24 - 2*dG2*dG3*gg14^2*gg23 ...
               + 2*gg11*gg44*dG2*dG3*gg23 - 2*dG2*dG4*gg13^2*gg24 ...
               + 2*dG2*dG4*gg13*gg14*gg23 + 2*gg11*gg33*dG2*dG4*gg24 ...
               + gg22*dG3^2*gg14^2 + gg11*dG3^2*gg24^2 - gg11*gg22*gg44*dG3^2 ...
               - 2*gg22*dG3*dG4*gg13*gg14 - 2*gg11*dG3*dG4*gg23*gg24 ...
               + gg22*dG4^2*gg13^2 + gg11*dG4^2*gg23^2 - gg11*gg22*gg33*dG4^2);
           
           den_bayes =  ...
           - gg13^2*gg24^2 + gg22*gg44*gg13^2 + 2*gg13*gg14*gg23*gg24 ...
           - gg14^2*gg23^2 + gg22*gg33*gg14^2 + gg11*gg44*gg23^2 ...
           + gg11*gg33*gg24^2 - gg11*gg22*gg33*gg44;
 
            % product of A-factors
            A_fac = ...
              gg13^2*gg24^2 - gg22*gg44*gg13^2 - 2*gg13*gg14*gg23*gg24 ...
            + gg14^2*gg23^2 - gg22*gg33*gg14^2 - gg11*gg44*gg23^2 ...
            - gg11*gg33*gg24^2 + gg11*gg22*gg33*gg44;
 
            
            % log of posterior 
            bayes_mat( ii_11_ww, ii_22_ww ) = (num_bayes / den_bayes) ...
                - 0.5 * log( A_fac );

        end
  
    end
  
end

if ~find( isnan( bayes_mat(:) ) ) % Any frequency pairs on the diagonal?
    disp('No diagonal points.')
    data_out.bayes_mat = bayes_mat;
    return
end

std_11 = std( diff( ww_11_vec ) );
std_22 = std( diff( ww_22_vec ) );
std_thresh = 1.e-10;

if std_11 > std_thresh | std_22 > std_thresh
    disp('Warning: Diagonal entries may not be correct.' )
end

% Interpolate the points on the diagonal
for ii_11_ww = 1: num_11_ww

    ww_11 = ww_11_vec( ii_11_ww );

    for ii_22_ww = 1: num_22_ww

        ww_22 = ww_22_vec( ii_22_ww );

        if ww_22 == ww_11 

            % indices including 8 nearest neighbors 

            id_11_aa = ii_11_ww - 1;
            if id_11_aa < 1
                id_11_aa = 1;
            end
            
            id_11_bb = ii_11_ww + 1;
            if id_11_bb > num_11_ww
                id_11_bb = num_11_ww;
            end

            id_22_aa = ii_22_ww - 1;
            if id_22_aa < 1
                id_22_aa = 1;
            end
            
            id_22_bb = ii_22_ww + 1;
            if id_22_bb > num_22_ww
                id_22_bb = num_22_ww;
            end

            square_mat = bayes_mat( id_11_aa: id_11_bb, id_22_aa: id_22_bb);
            square_vec = square_mat(:); % collapse to vector
            id_good = find( ~isnan( square_vec ) );

            % Interpolate from neighbors to the diagonal
            bayes_mat( ii_11_ww, ii_22_ww ) = mean( square_vec( id_good ));

        end

    end
end

data_out.bayes_mat = bayes_mat;
return

xx_vec    = data_in.xx_vec(:);   % samples
tt_vec    = data_in.tt_vec(:);   % sample times  
ww_11_vec = data_in.ww_11_vec(:);% first frequecies (radians per unit time)
ww_22_vec = data_in.ww_22_vec(:);% second frequecies

if isfield( data_in, 'wt_vec') 
    wt_vec = data_in.wt_vec;
    if find( wt_vec < 0 )
        error('Error: negative weight')
    end
    wt_vec = wt_vec / sum( wt_vec );% Ensure normalization
    do_weights = 1;
else
    do_weights = 0;
end

num_11_ww = length( ww_11_vec );% number of frequencies
num_22_ww = length( ww_22_vec );

bayes_nosc_mat = NaN * ones( num_11_ww, num_22_ww );% Initialize arrays


for ii_11_ww = 1: num_11_ww

    ww_11 = ww_11_vec( ii_11_ww );

    % Implement the Lomb phase shift term
    if do_weights > 0 
        csum_11 = sum( wt_vec .* cos( 2.0 * ww_11 * tt_vec ) );
        ssum_11 = sum( wt_vec .* sin( 2.0 * ww_11 * tt_vec ) );
    else
        csum_11 = sum( cos( 2.0 * ww_11 * tt_vec ) );
        ssum_11 = sum( sin( 2.0 * ww_11 * tt_vec ) );
    end
    wtau_11 = 0.5 * atan2( ssum_11, csum_11 );
    tt_11 = ww_11 * tt_vec - wtau_11;
    sin_11_vec =  sin( tt_11 );
    cos_11_vec =  cos( tt_11 );

    if do_weights > 0 
        SS11 = sum( wt_vec .* sin_11_vec .^2 );
        CC11 = sum( wt_vec .* cos_11_vec .^2 );
        XXS1 = sum( wt_vec .* xx_vec .* sin_11_vec );
        XXC1 = sum( wt_vec .* xx_vec .* cos_11_vec );
    else
        SS11 = sum( sin_11_vec .^2 );
        CC11 = sum( cos_11_vec .^2 );
        XXS1 = sum( xx_vec .* sin_11_vec );
        XXC1 = sum( xx_vec .* cos_11_vec );
    end

    for ii_22_ww = 1: num_22_ww

        ww_22 = ww_22_vec( ii_22_ww );

        if ww_22 ~=  ww_11  % Ignore the diagonal for now 
             
            % Implement the Lomb phase shift term
            if do_weights > 0 
                csum_22 = sum( wt_vec .* cos( 2.0 * ww_22 * tt_vec ) ); % phase term
                ssum_22 = sum( wt_vec .* sin( 2.0 * ww_22 * tt_vec ) );
            else
                csum_22 = sum( cos( 2.0 * ww_22 * tt_vec ) ); % phase term
                ssum_22 = sum( sin( 2.0 * ww_22 * tt_vec ) );
            end
            wtau_22 = 0.5 * atan2( ssum_22, csum_22 );
            tt_22 = ww_22 * tt_vec - wtau_22;
            sin_22_vec =  sin( tt_22 );
            cos_22_vec =  cos( tt_22 );
            
            if do_weights > 0 

                SS22 = sum( wt_vec .* sin_22_vec .^2 );
                CC22 = sum( wt_vec .* cos_22_vec .^2 );
                XXS2 = sum( wt_vec .* xx_vec .* sin_22_vec );
                XXC2 = sum( wt_vec .* xx_vec .* cos_22_vec );
                
                SS12 = sum( wt_vec .* sin_11_vec .* sin_22_vec );% Cross 
                CC12 = sum( wt_vec .* cos_11_vec .* cos_22_vec );
                CS12 = sum( wt_vec .* cos_11_vec .* sin_22_vec );
                SC12 = sum( wt_vec .* sin_11_vec .* cos_22_vec );

            else

                SS22 = sum( sin_22_vec .^2 );
                CC22 = sum( cos_22_vec .^2 );
                XXS2 = sum( xx_vec .* sin_22_vec );
                XXC2 = sum( xx_vec .* cos_22_vec );
                
                SS12 =  sum( sin_11_vec .* sin_22_vec );% Cross terms
                CC12 =  sum( cos_11_vec .* cos_22_vec );
                CS12 =  sum( cos_11_vec .* sin_22_vec );
                SC12 =  sum( sin_11_vec .* cos_22_vec );

            end
              
           %===================================================================
            
         num_bayes_nosc = ...
            - 2*CC12^2*SS12*XXS1*XXS2 + SS22*CC12^2*XXS1^2 + SS11*CC12^2*XXS2^2 ...
            + 2*CC12*CS12*SC12*XXS1*XXS2 + 2*CC12*CS12*SS12*XXC2*XXS1 ...
            - 2*SS11*CC12*CS12*XXC2*XXS2 + 2*CC12*SC12*SS12*XXC1*XXS2 ...
            - 2*SS22*CC12*SC12*XXC1*XXS1 - 2*CC12*SS12^2*XXC1*XXC2 ...
            + 2*SS11*SS22*CC12*XXC1*XXC2 - 2*CS12^2*SC12*XXC2*XXS1 ...
            + SS11*CS12^2*XXC2^2 + CC22*CS12^2*XXS1^2 - 2*CS12*SC12^2*XXC1*XXS2 ...
            + 2*CS12*SC12*SS12*XXC1*XXC2 - 2*CC22*CS12*SS12*XXC1*XXS1 ...
            + 2*CC22*SS11*CS12*XXC1*XXS2 + SS22*SC12^2*XXC1^2 ...
            + CC11*SC12^2*XXS2^2 - 2*CC11*SC12*SS12*XXC2*XXS2 ...
            + 2*CC11*SS22*SC12*XXC2*XXS1 + CC22*SS12^2*XXC1^2 ...
            + CC11*SS12^2*XXC2^2 + 2*CC11*CC22*SS12*XXS1*XXS2 ...
            - CC22*SS11*SS22*XXC1^2 - CC11*SS11*SS22*XXC2^2 ...
            - CC11*CC22*SS22*XXS1^2 - CC11*CC22*SS11*XXS2^2;
            
        den_bayes_nosc = ...
        - CC12^2*SS12^2 + SS11*SS22*CC12^2 + 2*CC12*CS12*SC12*SS12 ...
        - CS12^2*SC12^2 + CC22*SS11*CS12^2 + CC11*SS22*SC12^2 + CC11*CC22*SS12^2 ...
        - CC11*CC22*SS11*SS22;

      bayes_nosc = num_bayes_nosc / den_bayes_nosc;


       bayes_nosc_mat( ii_11_ww, ii_22_ww ) = bayes_nosc;

  
        end
  
    end
  
end

if ~find( isnan( bayes_nosc_mat(:) ) ) % Any frequency pairs on the diagonal?
    disp('No diagonal points.')
    data_out.bayes_nosc_mat = bayes_nosc_mat;
    return
end

std_11 = std( diff( ww_11_vec ) );
std_22 = std( diff( ww_22_vec ) );
std_thresh = 1.e-10;

if std_11 > std_thresh | std_22 > std_thresh
    disp('Warning: Diagonal entries may not be correct.' )
end

% Interpolate the points on the diagonal
for ii_11_ww = 1: num_11_ww

    ww_11 = ww_11_vec( ii_11_ww );

    for ii_22_ww = 1: num_22_ww

        ww_22 = ww_22_vec( ii_22_ww );

        if ww_22 == ww_11 

            % indices including 8 nearest neighbors 

            id_11_aa = ii_11_ww - 1;
            if id_11_aa < 1
                id_11_aa = 1;
            end
            
            id_11_bb = ii_11_ww + 1;
            if id_11_bb > num_11_ww
                id_11_bb = num_11_ww;
            end

            id_22_aa = ii_22_ww - 1;
            if id_22_aa < 1
                id_22_aa = 1;
            end
            
            id_22_bb = ii_22_ww + 1;
            if id_22_bb > num_22_ww
                id_22_bb = num_22_ww;
            end

            square_mat = bayes_nosc_mat( id_11_aa: id_11_bb, id_22_aa: id_22_bb);
            square_vec = square_mat(:); % collapse to vector
            id_good = find( ~isnan( square_vec ) );

            % Interpolate from neighbors to the diagonal
            bayes_nosc_mat( ii_11_ww, ii_22_ww ) = mean( square_vec( id_good ));

        end

    end
end

data_out.bayes_nosc_mat = bayes_nosc_mat;
return