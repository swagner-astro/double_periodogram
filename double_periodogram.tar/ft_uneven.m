function data_out = ft_uneven( data_in )
% function data_out = ft_uneven( data_in )
%--------------------------------------------------------------------------
% Compute Fourier Transform of arbitrarily spaced data
% (Modified algorithm in ApJ 343, 1989, 874-887, Paper III)
% and the Lomb-Scargle periodogram 
%--------------------------------------------------------------------------
%  Input: data_in.xx_vec  -- Dependent variable samples
%         data_in.tt_vec  -- Corresponding sample times
%         data_in.ww_vec  -- Ealuate transform at these frequencies
%                            (radians per unit time)
%         data_in.ft_sign -- Sign of the transform
%         data_in.tt_zero -- Origin of time
%--------------------------------------------------------------------------
% Output: data_out.ft_vec -- Fourier transform (complex)
%         data_out.ls_vec -- Lomb-Scargle periodogram (real)
%--------------------------------------------------------------------------

if isfield( data_in, 'do_window')
    do_window = data_in.do_window;
else
    do_window = 0;% default: do window function
end

 xx_vec = data_in.xx_vec(:);  
 tt_vec = data_in.tt_vec(:);  
 ww_vec = data_in.ww_vec(:);  
 
ft_sign = data_in.ft_sign;
tt_zero = data_in.tt_zero;

num_xt = length( xx_vec );% number of samples
num_ww = length( ww_vec );% number of frequencies

%------------------------------------------
%          Start Frequency Loop 
%------------------------------------------

ft_vec = zeros( num_ww, 1 );
ls_vec = zeros( num_ww, 1 );

ft_schuster_vec = zeros( num_ww, 1 );


if do_window > 0 
    window_vec = zeros( num_ww, 1 );
end

cpu_0 = cputime;
for ii_ww = 1: num_ww
    
    wrun = ww_vec( ii_ww );
    
    % Schuster FT
    ft_schuster_vec( ii_ww ) = mean( xx_vec .* exp( - 1i * wrun * tt_vec ) );

    if wrun == 0
       
        % must deal with 0/0 singularity when omega = 0
        tau_zero = sum( tt_vec .* xx_vec ) / sum( xx_vec );
        
        ft_real  = sum( xx_vec ) / sqrt( num_xt );
        ft_imag  = sum( xx_vec .* ( tt_vec - tau_zero ) ) ...
           / sqrt( sum(        abs( tt_vec - tau_zero ) .^ 2 ) );
       
        ft_vec( ii_ww ) = complex( ft_real, ft_imag );
        ls_vec( ii_ww ) = abs( ft_vec( ii_ww ) ) .^2;
    window_vec( ii_ww ) = sqrt( num_xt );
        
    else
    
        csum = sum( cos( 2.0 * wrun * tt_vec ) );
        ssum = sum( sin( 2.0 * wrun * tt_vec ) );
    
        % Special conditions that will probably arise
        %  only for the case of even sampling
        check_vec = cos( 2.0 * wrun * tt_vec ) - 1;
        
        if rem( wrun, pi ) == 0 & max( abs( check_vec) ) < 1.e-10 
           disp('Warning: adjustment for special case; ')
           disp('If the spacing is not even, there may be an error.')
           csum = 0;
        end
  
        wtau = 0.5 * atan2( ssum, csum );
       
        %---------------------------------
        %      Sum over the samples
        %---------------------------------

        sumr = sum( xx_vec .* cos( wrun * tt_vec - wtau ) );
        sumi = sum( xx_vec .* sin( wrun * tt_vec - wtau ) );
        
        scos2 = sum( ( cos(  wrun * tt_vec - wtau ) ) .^ 2 );
        ssin2 = sum( ( sin(  wrun * tt_vec - wtau ) ) .^ 2 );

        ft_real = sumr / ( sqrt(2) * sqrt( scos2 ) );
        ft_imag = ft_sign * sumi / ( sqrt(2) * sqrt( ssin2 ) );
        %ft_imag = sumi / ( sqrt(2) * sqrt( ssin2 ) );
        phase_this = wtau - wrun * tt_zero;
        
        phase_vec( ii_ww ) = phase_this;
        ft_vec( ii_ww ) = complex( ft_real, ft_imag ) * exp( 1i * phase_this );
        
        if do_window > 0 
            
            % window?
            sumr_wind = sum( cos( wrun * tt_vec - wtau ) );
            sumi_wind = sum( sin( wrun * tt_vec - wtau ) );

            ft_window_real = sumr_wind / ( sqrt(2) * sqrt( scos2 ) );
            ft_window_imag = ft_sign * sumi_wind / ( sqrt(2) * sqrt( ssin2 ) );
            %ft_window_imag = sumi_wind / ( sqrt(2) * sqrt( ssin2 ) );

            ft_window_vec( ii_ww ) = complex( ft_window_real, ft_window_imag ) ...
                   * exp( 1i * phase_this );
        
        end
       
        % L-S periodogram 
        ls_vec( ii_ww ) = abs( ( sumr .^2 / scos2 ) + ( sumi .^2 / ssin2 ) );

    end
    
   % print_progress( ii_ww, num_ww, 10000, cpu_0 );
   
end

data_out.ft_vec = conj( ft_vec );
data_out.ls_vec = ls_vec;
data_out.ft_schuster_vec = ft_schuster_vec * sqrt( num_xt );
%data_out.phase_vec = phase_vec;

if do_window > 0
    data_out.ft_window_vec = ft_window_vec;
end
