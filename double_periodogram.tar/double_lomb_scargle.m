function data_out = double_lsp( data_in )

xx_vec    = data_in.xx_vec(:);   % samples
tt_vec    = data_in.tt_vec(:);   % sample times  
ww_11_vec = data_in.ww_11_vec(:);% first frequecies (radians per unit time)
ww_22_vec = data_in.ww_22_vec(:);% second frequecies

if isfield( data_in, 'wt_vec') 
    wt_vec = data_in.wt_vec;
    if find( wt_vec < 0 )
        error('Error: negative weight')
    end
    wt_vec = wt_vec / sum( wt_vec );% Ensure normalization
    do_weights = 1;
else
    do_weights = 0;
end

num_11_ww = length( ww_11_vec );% number of frequencies
num_22_ww = length( ww_22_vec );

dlsp_mat = NaN * ones( num_11_ww, num_22_ww );% Initialize arrays
  B1_mat = NaN * ones( num_11_ww, num_22_ww );
  B2_mat = NaN * ones( num_11_ww, num_22_ww );
  B3_mat = NaN * ones( num_11_ww, num_22_ww );
  B4_mat = NaN * ones( num_11_ww, num_22_ww );

for ii_11_ww = 1: num_11_ww

    ww_11 = ww_11_vec( ii_11_ww );

    % Implement the Lomb phase shift term
    if do_weights > 0 
        csum_11 = sum( wt_vec .* cos( 2.0 * ww_11 * tt_vec ) );
        ssum_11 = sum( wt_vec .* sin( 2.0 * ww_11 * tt_vec ) );
    else
        csum_11 = sum( cos( 2.0 * ww_11 * tt_vec ) );
        ssum_11 = sum( sin( 2.0 * ww_11 * tt_vec ) );
    end
    wtau_11 = 0.5 * atan2( ssum_11, csum_11 );
    tt_11 = ww_11 * tt_vec - wtau_11;
    sin_11_vec =  sin( tt_11 );
    cos_11_vec =  cos( tt_11 );

    if do_weights > 0

        % C --> 1  S --> 2 
        gg11 = sum( wt_vec .* abs( cos_11_vec ).^ 2);
        gg22 = sum( wt_vec .* abs( sin_11_vec ).^ 2);
        dG1  = sum( wt_vec .* xx_vec .* cos_11_vec );
        dG2  = sum( wt_vec .* xx_vec .* sin_11_vec );
 
    else

        gg11 = sum( abs( cos_11_vec ).^ 2);
        gg22 = sum( abs( sin_11_vec ).^ 2);
        dG1  = sum( xx_vec .* cos_11_vec );
        dG2  = sum( xx_vec .* sin_11_vec );
     
    end

    for ii_22_ww = 1: num_22_ww

       ww_22 = ww_22_vec( ii_22_ww );

       if ww_22 ~= ww_11  % Ignore the diagonal for now 
             
            % Implement the Lomb phase shift term
            if do_weights > 0 
                csum_22 = sum( wt_vec .* cos( 2.0 * ww_22 * tt_vec ) ); % phase term
                ssum_22 = sum( wt_vec .* sin( 2.0 * ww_22 * tt_vec ) );
            else
                csum_22 = sum( cos( 2.0 * ww_22 * tt_vec ) ); % phase term
                ssum_22 = sum( sin( 2.0 * ww_22 * tt_vec ) );
            end

            wtau_22 = 0.5 * atan2( ssum_22, csum_22 );
            tt_22 = ww_22 * tt_vec - wtau_22;
            sin_22_vec =  sin( tt_22 );
            cos_22_vec =  cos( tt_22 );
             
             if do_weights > 0 
    
                gg33 = sum( wt_vec .* abs( cos_22_vec ).^ 2);
                gg44 = sum( wt_vec .* abs( sin_22_vec ).^ 2);
                dG3  = sum( wt_vec .* xx_vec .* cos_22_vec );
                dG4  = sum( wt_vec .* xx_vec .* sin_22_vec );
    
                gg13 =  sum( wt_vec .* cos_11_vec .* cos_22_vec );
                gg24 =  sum( wt_vec .* sin_11_vec .* sin_22_vec );
                gg14 =  sum( wt_vec .* cos_11_vec .* sin_22_vec );
                gg23 =  sum( wt_vec .* sin_11_vec .* cos_22_vec );
    
            else
           
                gg33 = sum( abs( cos_22_vec ).^ 2);
                gg44 = sum( abs( sin_22_vec ).^ 2);
                dG3  = sum( xx_vec .* cos_22_vec );
                dG4  = sum( xx_vec .* sin_22_vec );
    
                gg13 =  sum( cos_11_vec .* cos_22_vec );
                gg24 =  sum( sin_11_vec .* sin_22_vec );
                gg14 =  sum( cos_11_vec .* sin_22_vec );
                gg23 =  sum( sin_11_vec .* cos_22_vec );
    
            end
                      
       %===================================================================
        
     all_den = - gg13^2*gg24^2 + gg22*gg44*gg13^2 + 2*gg13*gg14*gg23*gg24 ...
               - gg14^2*gg23^2 + gg22*gg33*gg14^2 + gg11*gg44*gg23^2 ...
               + gg11*gg33*gg24^2 - gg11*gg22*gg33*gg44;
 
            %============== 1 ==================
            
            Q_dG1 = gg24^2*gg33 + gg23^2*gg44 - gg22*gg33*gg44;
            Q_dG2 = -1 * ( gg14*gg24*gg33 + gg13*gg23*gg44 ); 
            Q_dG3 = gg14*gg23*gg24 - gg13*gg24^2 + gg13*gg22*gg44;
            Q_dG4 = gg13*gg23*gg24 - gg14*gg23^2 + gg14*gg22*gg33;
            
            B1 = (Q_dG1*dG1 + Q_dG2*dG2 + Q_dG3*dG3 + Q_dG4*dG4) / all_den;
            
            %============== 2 ==================
            
            Q_dG1 = -1 * ( gg14*gg24*gg33 + gg13*gg23*gg44 ); 
            Q_dG2 = gg14^2*gg33 + gg13^2*gg44 - gg11*gg33*gg44;
            Q_dG3 = gg13*gg14*gg24 - gg14^2*gg23 + gg11*gg23*gg44;
            Q_dG4 = gg13*gg14*gg23 - gg13^2*gg24 + gg11*gg24*gg33;
            
            B2 = (Q_dG1*dG1 + Q_dG2*dG2 + Q_dG3*dG3 + Q_dG4*dG4) / all_den;
            
            %============== 3 ==================
            
            Q_dG1 = gg14*gg23*gg24 - gg13*gg24^2 + gg13*gg22*gg44;
            Q_dG2 = gg13*gg14*gg24 - gg14^2*gg23 + gg11*gg23*gg44;
            Q_dG3 = gg11*gg24^2 + gg14^2*gg22 - gg11*gg22*gg44;
            Q_dG4 = -1 * ( gg13*gg14*gg22 + gg11*gg23*gg24 ); 
            
            B3 = (Q_dG1*dG1 + Q_dG2*dG2 + Q_dG3*dG3 + Q_dG4*dG4) / all_den;
            
            %============== 4 ==================
            
            Q_dG1 = gg13*gg23*gg24 - gg14*gg23^2 + gg14*gg22*gg33;
            Q_dG2 = gg13*gg14*gg23 - gg13^2*gg24 + gg11*gg24*gg33;
            Q_dG3 = -1 * ( gg13*gg14*gg22 + gg11*gg23*gg24 ); 
            Q_dG4 = gg11*gg23^2 + gg13^2*gg22 - gg11*gg22*gg33;
            
            B4 = (Q_dG1*dG1 + Q_dG2*dG2 + Q_dG3*dG3 + Q_dG4*dG4) / all_den;
            
            %===================================

            dp = ...
            gg11*B1^2 + 2*gg13*B1*B3 + 2*gg14*B1*B4 - 2*dG1*B1 + gg22*B2^2 ...
            + 2*gg23*B2*B3 + 2*gg24*B2*B4 - 2*dG2*B2 + gg33*B3^2 - 2*dG3*B3 ...
            + gg44*B4^2 - 2*dG4*B4;

           dlsp_mat( ii_11_ww, ii_22_ww ) = dp;

           B1_mat( ii_11_ww, ii_22_ww ) = B1;
           B2_mat( ii_11_ww, ii_22_ww ) = B2;
           B3_mat( ii_11_ww, ii_22_ww ) = B3;
           B4_mat( ii_11_ww, ii_22_ww ) = B4;

        end
  
    end
  
end

data_out.B1_mat = B1_mat;% best values of these parameters may be useful
data_out.B2_mat = B2_mat;
data_out.B3_mat = B3_mat;
data_out.B4_mat = B4_mat;

if ~find( isnan( dlsp_mat(:) ) ) % Any frequency pairs on the diagonal?
    disp('No diagonal points.')
    data_out.dlsp_mat = dlsp_mat;
    return
end

% Interpolate the points on the diagonal
for ii_11_ww = 1: num_11_ww

    ww_11 = ww_11_vec( ii_11_ww );

    for ii_22_ww = 1: num_22_ww

        ww_22 = ww_22_vec( ii_22_ww );

        if ww_22 == ww_11 

            % indices including 8 nearest neighbors 

            id_11_aa = ii_11_ww - 1;
            if id_11_aa < 1
                id_11_aa = 1;
            end
            
            id_11_bb = ii_11_ww + 1;
            if id_11_bb > num_11_ww
                id_11_bb = num_11_ww;
            end

            id_22_aa = ii_22_ww - 1;
            if id_22_aa < 1
                id_22_aa = 1;
            end
            
            id_22_bb = ii_22_ww + 1;
            if id_22_bb > num_22_ww
                id_22_bb = num_22_ww;
            end

            square_mat = dlsp_mat( id_11_aa: id_11_bb, id_22_aa: id_22_bb);
            square_vec = square_mat(:); % collapse to vector
            id_good = find( ~isnan( square_vec ) );

            % Interpolate from neighbors to the diagonal
            dlsp_mat( ii_11_ww, ii_22_ww ) = mean( square_vec( id_good ));

        end

    end
end

data_out.dlsp_mat = dlsp_mat;
return
