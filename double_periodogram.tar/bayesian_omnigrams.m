% bayesian_ommigrams.m
%% Marginalize the likelihood for sinusoidal data models of any order.
% C.f. Chapter 3 of Larry Bretthorst's book 
% Bayesian Spectral Analysis and Parameter Estimation

mm = 4; % Set the number of terms in the modeln (e.g., 4 for two sinusoids)


disp('==================================================================')
disp(' Marginalized Likelihood (Bretthorst) Periodograms.')
disp('==================================================================')

disp([])

for do_lomb = 0:1;% Use the Lomb phase term if do_lomb not 0


     disp([])
    if do_lomb == 0
        disp('DBSP: Multiple Bretthorst-Schuster Periodogram (no Lomb phase shift).')
    else
        disp('DLSP: Multple Bretthorst-Schuster Periodogram (with Lomb phase shift).')
    end
    
% First Define symbolic variables
for jj = 1:mm

    % Model amplitude variables  B_{j} 
    st = ['B' int2str( jj ) ];
    eval( ['B' int2str( jj ) ' = sym(st); '] );

    % Inner products of basis functions with the data:
    % dG_{j} ==  (1/N) Sum_{i} [ d_{i} G_{j}( t_{i} ) 
    st = ['dG' int2str( jj ) ];
    eval( ['dG' int2str( jj ) ' = sym(st); '] );

    % Cross products of basis functions:
    % gg_{j,k} = (1/N) Sum_{i} G_{j}( t_{i} ) G_{k}( t_{i} ) 
    for kk = jj: mm 
        st = sym( ['gg' int2str( jj ) int2str( kk ) ]);
        eval( [' gg' int2str( jj ) int2str( kk )  '= st; '] );
    end
end

% Data inner products for the log-likelihood
for jj = 1:mm

    this_term = [ '-2*B' int2str(jj ) '* dG' int2str(jj )];
    if jj == 1
       Q = str2sym( this_term );
    else
       Q = Q + str2sym( this_term );
    end

end

% Basis inner products: diagonal terms 
for jj = 1:mm
    this_term = str2sym( ['B' int2str(jj ) '^2 * gg'  int2str(jj) int2str(jj)  ] );
    Q = Q +  this_term;
end

if do_lomb == 0 
    % Basis inner products: above diagonal terms 
    for jj = 1:mm
    for kk = jj+1: mm 
        this_term = str2sym( ['2 * B' int2str(jj ) '* ' ...
                                  'B' int2str(kk ) '* ' ...
                                 'gg' int2str(jj) int2str(kk)  ] );
        Q = Q +  this_term;
    end
    end
else
    % Basis inner products: above diagonal terms 
    % for Lomb, skip if jj odd and kk == jj + 1
    for jj = 1:mm
    for kk = jj+1: mm 
        this_term = str2sym( ['2 * B' int2str(jj ) '* ' ...
                                      'B' int2str(kk ) '* ' ...
                                     'gg' int2str(jj) int2str(kk)  ] );
        % remove if jj odd and kk == jj + 1
        if rem( jj, 2 ) ==  1 & kk == jj + 1
            %disp([ 'no soap ' char( this_term  )] )
        else
            Q = Q +  this_term;
        end
    end
    end
end
 
% Now evaluate the Gaussian integrals
for jj = 1: mm 

    B_this = ['B' int2str( jj )  ];

    QC = coeffs( Q, B_this  );
    AA_this = QC(3);
    BB_this = QC(2);
    CC_this = QC(1);

    fac_vec( jj ) = AA_this;
    % Remaining argument of the exponential:
    Q_arg_this = BB_this .^2 /( 4 * AA_this );
    Q = -Q_arg_this + CC_this;

end

%%
%Two factors to be inserted into operational code:
P = simplify( -Q );
A_fac = simplify( prod( fac_vec ) );

[ num_bayes, den_bayes ] = numden( P );
%result =  (num_bayes / den_bayes) - 0.5 * log( A_fac );

% Organize the  numerators: terms involving the data 
st = who( ['dG*']);

[ cc, ff ] = coeffs( num_bayes, st ); % [ dG1 dG2 dG3 dG4 ]);
num_terms = length( cc );

disp('---------------------------------------------------------------------')

disp( 'Inner Product Terms For Numerator ')
for ii = 1: num_terms

    %disp([ '============== ' int2str( ii )  ' ==================' ])
    cc_this = cc( ii );
    facs_this = factor( cc_this );
    num_facs = length( facs_this );

    name_this = char( ff(ii) );
    name_this( findstr( name_this, '^' ) ) = 'p';
    name_this( findstr( name_this, '*' ) ) = 'x';

    if num_facs == 1
        disp( [ 'Q_' name_this  ' = ' char( facs_this ) ';'] )
    elseif num_facs == 2
        disp( [ 'Q_' name_this  ' = ' char( facs_this(1) ) ' * ( ' char( facs_this(2) ) ' ); '] )
    else
        error(['too many' ])
    end
  
end

%%
st_numerator = [];
for ii = 1: num_terms
    
    name_this = char( ff(ii) );
    name_this( findstr( name_this, '^' ) ) = 'p';
    name_this( findstr( name_this, '*' ) ) = 'x';

    st_here = [ 'Q_' name_this '*' char( ff(ii) ) ];

    if ii < num_terms
       % st_numerator  = [ st_numerator 'Q_' name_this '*' char( ff(ii) ) ' + ' ];
       st_numerator  = [ st_numerator st_here ' + ' ];
    else
        %st_numerator = [ st_numerator 'Q_' name_this '*' char( ff(ii) ) ';' ];
        st_numerator = [ st_numerator st_here ';' ];
    end
end


%%
disp('---------------------------------------------------------------------')
disp( 'Numerator: ')
show_it( 'numerator', st_numerator); % disp( st_numerator )
disp('---------------------------------------------------------------------')
disp( 'Denomninator: ')
show_it( 'denominator', char( den_bayes  ) );% disp( den_bayes )
disp('=====================================================================')

disp('---------------------------------------------------------------------')
disp( 'A factors: ')
show_it( 'A_fac', char( A_fac ) );% disp( den_bayes )
disp('=====================================================================')

end

  