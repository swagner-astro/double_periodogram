function data_out = double_bretthorst_schuster( data_in )

xx_vec    = data_in.xx_vec(:);   % samples
tt_vec    = data_in.tt_vec(:);   % sample times  
ww_11_vec = data_in.ww_11_vec(:);% first frequecies (radians per unit time)
ww_22_vec = data_in.ww_22_vec(:);% second frequecies

if isfield( data_in, 'wt_vec') 
    wt_vec = data_in.wt_vec;
    if find( wt_vec < 0 )
        error('Error: negative weight')
    end
    wt_vec = wt_vec / sum( wt_vec );% Ensure normalization
    do_weights = 1;
else
    do_weights = 0;
end

num_11_ww = length( ww_11_vec );% number of frequencies
num_22_ww = length( ww_22_vec );

bayes_mat = NaN * ones( num_11_ww, num_22_ww );% Initialize arrays

for ii_11_ww = 1: num_11_ww

    ww_11      = ww_11_vec( ii_11_ww );
    cos_11_vec = cos( ww_11 * tt_vec ); 
    sin_11_vec = sin( ww_11 * tt_vec ); 

    if do_weights > 0 
        % C --> 1  S --> 2 
        gg11 = sum( wt_vec .* abs( cos_11_vec ).^ 2);
        gg22 = sum( wt_vec .* abs( sin_11_vec ).^ 2);
        gg12 = sum( wt_vec .* cos_11_vec .* sin_11_vec );
        dG1  = sum( wt_vec .* xx_vec .* cos_11_vec );
        dG2  = sum( wt_vec .* xx_vec .* sin_11_vec );
  
    else

        gg11 = sum( abs( cos_11_vec ).^ 2);
        gg22 = sum( abs( sin_11_vec ).^ 2);
        gg12 = sum( cos_11_vec .* sin_11_vec );
        dG1  = sum( xx_vec .* cos_11_vec );
        dG2  = sum( xx_vec .* sin_11_vec );
     
    end

    for ii_22_ww = 1: num_22_ww

        ww_22 = ww_22_vec( ii_22_ww );

        % Ignore the diagonal for now 
        if ww_22 ~=  ww_11  

            cos_22_vec = cos( ww_22 * tt_vec );
            sin_22_vec = sin( ww_22 * tt_vec );
           
           % C22 --> 3  S22 --> 4 

            if do_weights > 0 

                gg33 = sum( wt_vec .* abs( cos_22_vec ).^ 2);
                gg44 = sum( wt_vec .* abs( sin_22_vec ).^ 2);
                gg34 = sum( wt_vec .* cos_22_vec .* sin_22_vec );
                dG3  = sum( wt_vec .* xx_vec .* cos_22_vec );
                dG4  = sum( wt_vec .* xx_vec .* sin_22_vec );

                gg13 =  sum( wt_vec .* cos_11_vec .* cos_22_vec );
                gg24 =  sum( wt_vec .* sin_11_vec .* sin_22_vec );

                gg14 =  sum( wt_vec .* cos_11_vec .* sin_22_vec );
                gg23 =  sum( wt_vec .* sin_11_vec .* cos_22_vec );

            else
           
                gg33 = sum( abs( cos_22_vec ).^ 2);
                gg44 = sum( abs( sin_22_vec ).^ 2);
                gg34 = sum( cos_22_vec .* sin_22_vec );
                dG3  = sum( xx_vec .* cos_22_vec );
                dG4  = sum( xx_vec .* sin_22_vec );

                gg13 =  sum( cos_11_vec .* cos_22_vec );
                gg24 =  sum( sin_11_vec .* sin_22_vec );

                gg14 =  sum( cos_11_vec .* sin_22_vec );
                gg23 =  sum( sin_11_vec .* cos_22_vec );

            end

            % Basis function terms; could be pre-computed for a given sampling 
            Q_dG1p2 = gg22*gg34^2 + gg24^2*gg33 + gg23^2*gg44 - 2*gg23*gg24*gg34 - gg22*gg33*gg44;
            Q_dG1xdG2 = 2 * ( gg13*gg24*gg34 - gg12*gg34^2 + gg14*gg23*gg34 - gg14*gg24*gg33 - gg13*gg23*gg44 + gg12*gg33*gg44 ); 
            Q_dG1xdG3 = -2 * ( gg13*gg24^2 - gg14*gg23*gg24 - gg12*gg24*gg34 + gg14*gg22*gg34 + gg12*gg23*gg44 - gg13*gg22*gg44 ); 
            Q_dG1xdG4 = 2 * ( gg13*gg23*gg24 - gg14*gg23^2 + gg12*gg23*gg34 - gg12*gg24*gg33 - gg13*gg22*gg34 + gg14*gg22*gg33 ); 
            Q_dG2p2 = gg11*gg34^2 + gg14^2*gg33 + gg13^2*gg44 - 2*gg13*gg14*gg34 - gg11*gg33*gg44;
            Q_dG2xdG3 = 2 * ( gg13*gg14*gg24 - gg14^2*gg23 + gg12*gg14*gg34 - gg11*gg24*gg34 - gg12*gg13*gg44 + gg11*gg23*gg44 ); 
            Q_dG2xdG4 = -2 * ( gg13^2*gg24 - gg13*gg14*gg23 - gg12*gg13*gg34 + gg12*gg14*gg33 + gg11*gg23*gg34 - gg11*gg24*gg33 ); 
            Q_dG3p2 = gg11*gg24^2 + gg14^2*gg22 + gg12^2*gg44 - 2*gg12*gg14*gg24 - gg11*gg22*gg44;
            Q_dG3xdG4 = 2 * ( gg12*gg13*gg24 - gg12^2*gg34 + gg12*gg14*gg23 - gg13*gg14*gg22 - gg11*gg23*gg24 + gg11*gg22*gg34 ); 
            Q_dG4p2 = gg11*gg23^2 + gg13^2*gg22 + gg12^2*gg33 - 2*gg12*gg13*gg23 - gg11*gg22*gg33;

  numerator = Q_dG1p2*dG1^2     + Q_dG1xdG2*dG1*dG2 + Q_dG1xdG3*dG1*dG3 ...
            + Q_dG1xdG4*dG1*dG4 + Q_dG2p2*dG2^2     + Q_dG2xdG3*dG2*dG3 ...
            + Q_dG2xdG4*dG2*dG4 + Q_dG3p2*dG3^2     + Q_dG3xdG4*dG3*dG4 ...
            + Q_dG4p2*dG4^2;

denominator = (- gg12^2*gg34^2 + gg33*gg44*gg12^2 ...
             - 2*gg44*gg12*gg13*gg23 + 2*gg12*gg13*gg24*gg34 ...
             + 2*gg12*gg14*gg23*gg34 - 2*gg33*gg12*gg14*gg24 ...
               - gg13^2*gg24^2 + gg22*gg44*gg13^2 + 2*gg13*gg14*gg23*gg24 ...
             - 2*gg22*gg13*gg14*gg34 - gg14^2*gg23^2 + gg22*gg33*gg14^2 ...
               + gg11*gg44*gg23^2 - 2*gg11*gg23*gg24*gg34 + gg11*gg33*gg24^2 ...
               + gg11*gg22*gg34^2 - gg11*gg22*gg33*gg44);

            % product of A-factors
            A_fac = gg12^2*gg34^2 - gg33*gg44*gg12^2 + 2*gg44*gg12*gg13*gg23 ...
            - 2*gg12*gg13*gg24*gg34 - 2*gg12*gg14*gg23*gg34 + 2*gg33*gg12*gg14*gg24 ...
            + gg13^2*gg24^2 - gg22*gg44*gg13^2 - 2*gg13*gg14*gg23*gg24 ...
            + 2*gg22*gg13*gg14*gg34 + gg14^2*gg23^2 - gg22*gg33*gg14^2 ...
            - gg11*gg44*gg23^2 + 2*gg11*gg23*gg24*gg34 - gg11*gg33*gg24^2 ...
            - gg11*gg22*gg34^2 + gg11*gg22*gg33*gg44;
 
            % log of posterior 
            bayes_mat( ii_11_ww, ii_22_ww ) = (numerator / denominator) ...
                - 0.5 * log( A_fac );
            
        end

    end

end

if ~find( isnan( bayes_mat(:) ) ) % Any frequency pairs on the diagonal?
    data_out.bayes_mat = bayes_mat_mat;
    return
end

std_11 = std( diff( ww_11_vec ) );
std_22 = std( diff( ww_22_vec ) );
std_thresh = 1.e-10;

if std_11 > std_thresh | std_22 > std_thresh
    disp('Warning: Diagonal entries may not be correct.' )
end

% Interpolate the points on the diagonal
for ii_11_ww = 1: num_11_ww

    ww_11 = ww_11_vec( ii_11_ww );

    for ii_22_ww = 1: num_22_ww

        ww_22 = ww_22_vec( ii_22_ww );

        if ww_22 == ww_11 

            % indices including 8 nearest neighbors 

            id_11_aa = ii_11_ww - 1;
            if id_11_aa < 1
                id_11_aa = 1;
            end
            
            id_11_bb = ii_11_ww + 1;
            if id_11_bb > num_11_ww
                id_11_bb = num_11_ww;
            end

            id_22_aa = ii_22_ww - 1;
            if id_22_aa < 1
                id_22_aa = 1;
            end
            
            id_22_bb = ii_22_ww + 1;
            if id_22_bb > num_22_ww
                id_22_bb = num_22_ww;
            end

            square_mat = bayes_mat( id_11_aa: id_11_bb, id_22_aa: id_22_bb);
            square_vec = square_mat(:); % collapse to vector
            id_good = find( ~isnan( square_vec ) );

            % Interpolate from neighbors to the diagonal
            bayes_mat( ii_11_ww, ii_22_ww ) = mean( square_vec( id_good ));

        end

    end
end

data_out.bayes_mat = bayes_mat;
